# CSK — Penggantian Aset Foto Booth Channel 512

Paket ini berisi enam foto WebP sumber ber-watermark CSK, resolusi 1200 × 800 px.

## Cara memasang
1. Ekstrak ZIP di root repository `cahaya-selatan-kreasindo`.
2. Izinkan file di dalam `src/img/` menggantikan file dengan nama yang sama.
3. Commit dan push perubahan ke branch deployment (biasanya `main`).
4. Tunggu proses build/deploy selesai, lalu hard refresh halaman portofolio Booth Channel 512.

## Pemetaan file
- `booth-512-slow-move-bazaar.webp` — foto utama booth.
- `slow-move-bazaar-signage.webp` — detail signage 512.
- `slow-move-bazaar-booth-detail.webp` — detail booth/display.
- `slow-move-bazaar-event-activity.webp` — suasana event.
- `slow-move-bazaar-installation.webp` — proses instalasi.
- `slow-move-bazaar-setup.webp` — proses persiapan/setup.

## Catatan teknis
Komponen `src/components/Picture.astro` pada repository sudah mengatur keenam nama file di atas agar disajikan langsung sebagai file asli (`<img src>`), bukan diproses ulang oleh optimizer Astro. Karena itu, penggantian aset di `src/img/` adalah perbaikan utama; tidak perlu mengubah layout atau watermark.
